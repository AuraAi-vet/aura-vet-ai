# Contributing to Aura Vet AI

👋 Thanks for your interest! Here’s how you can help:

---

## 🛠️ How to Contribute

1️⃣ Fork the repository  
2️⃣ Create a new branch (`git checkout -b feature/your-feature`)  
3️⃣ Make your changes  
4️⃣ Commit with clear messages  
5️⃣ Push your branch  
6️⃣ Create a Pull Request  

---

## 🚀 Code of Conduct

Please be respectful and inclusive in all interactions.  

---

## 🐛 Issues & Bugs

Found a bug? Open an issue in the Issues tab with a clear title and description.  

---

Let’s make Aura Vet AI a success together! 🐾